
%===================================================== 
% Mise � jours Hiver 2024: Ahmed Joubair Ing., Ph.D.
%===================================================== 
% Entr�e : les quatres variables articulaires du robot
% Sortie : x, y, z, Ex, Ey, Ez de F_outil par rapport au F_R
%

function pose = Cinematique_directe(d1, theta2, theta3, theta4)

% Conversion de degr�s en radians (car Matlab fonctionne en radians)
d1 = d1;
theta2 = theta2*pi/180;
theta3 = theta3*pi/180;
theta4 = theta4*pi/180;

% Calcul des matrices "Hi,i-1" avec la fonction dh (Denavit Hartenberg)
H10 = dh(theta1+pi/2, -300, 0, pi/2);
H21 = dh(...
H32 = dh(...
H43 = dh(...

% Matrice de transformation H0,atelier
H0R =  ...
   
% Matrice de transformation Houtil,4
Ho4 = ...

% Matrice homog�ne qui d�finit la pose du r�f�rentiel F_outil
% par rapport au r�f�rentiel F_R
H = H0R*H10*H21*H32*H43*Ho4;

% Calcul de Ez, Ey, Ex(convention XYZ d'angles d'Euler)
 if abs(H(3,1)) == 1
    Ey = -H(3,1)*90;
    Ex= 0; % la valeur de Ex peut �tre arbitraire, mais on choisit Ex= 0
    Ez = atan2(-H(3,1)*H(2,3),H(2,2))*180/pi;
 else
    % il y a deux solutions dans la plage [-180�,180�]
    Ey = atan2(-H(3,1),sqrt(H(1,1)^2+H(2,1)^2))*180/pi;
    cp = cos(Ey*pi/180);
    Ez = atan2(H(2,1)/cp,H(1,1)/cp)*180/pi;
    Ex= atan2(H(3,2)/cp,H(3,3)/cp)*180/pi;
 end
 
 % R�sultat
 pose.x = H(1,4);
 pose.y = H(2,4);
 pose.z = H(3,4);
 pose.Ex = Ex;
 pose.Ey = Ey;
 pose.Ez = Ez;
 
% Matrice Hi,i-1
function A = dh(theta,d,a,t)
A = [cos(theta), -sin(theta)*cos(t),   sin(theta)*sin(t), a*cos(theta);
     sin(theta),  cos(theta)*cos(t),  -cos(theta)*sin(t), a*sin(theta);
              0,             sin(t),              cos(t),            d;
              0,                  0,                   0,            1];
