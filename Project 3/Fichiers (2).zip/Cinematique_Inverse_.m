% Mise � jour: Hiver 2024 (Ahmed Joubair)
% Entr�e : x, y, z, ex, ey, ez de F_outil par rapport au F_R
% Sortie : les quatres variables articulaires du robot

function q = Cinematique_Inverse_v2(x,y,z,ex,ey,ez)

% Matrice homog�ne qui d�finit la pose du r�f�rentiel F_outil
% par rapport au r�f�rentiel F_R
ex = ex*pi/180;
ey = ey*pi/180;
ez = ez*pi/180;
H_outil_R = [ cos(ez)*cos(ey), cos(ez)*sin(ey)*sin(ex)-sin(ez)*cos(ex), cos(ez)*sin(ey)*cos(ex)+sin(ez)*sin(ex), x;
      sin(ez)*cos(ey), sin(ez)*sin(ey)*sin(ex)+cos(ez)*cos(ex), sin(ez)*sin(ey)*cos(ex)-cos(ez)*sin(ex), y;
            -sin(ey),                      cos(ey)*sin(ex),                      cos(ey)*cos(ex), z;
                  0,                                  0,                                 0,  1];



% Matrice de transformation H0,atelier
H0R =  ...
   
% Matrice de transformation Houtil,4
Ho4 = ...

H= H0R^(-1)*H_outil_R*Ho4^(-1)

% D�composition de la matrice H
nx = H(1,1);
ny = H(2,1);
nz = H(3,1);
ox = H(1,2);
oy = H(2,2);
oz = H(3,2);
ax = H(1,3);
ay = H(2,3);
az = H(3,3);
px = H(1,4);
py = H(2,4);
pz = H(3,4);

% Calcul de d1
d1 = ...

% Calcul de theta2
theta2 = ...

% Calcul de theta3
theta3 = ...

% Calcul de theta4:
theta4 = ...

% Conversion en degr�s
theta2 = ...
theta3 = ...;
theta4 = ...;

% R�sultat
q.d1 = d1;
q.theta2 = theta2;
q.theta3 = theta3;
q.theta4 = theta4;